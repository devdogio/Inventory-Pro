﻿#if PLY_GAME

using Devdog.InventoryPro.Integration.plyGame;

namespace Devdog.InventoryPro
{
    public partial class ItemDatabase
    {
        public plyGameAttributeDatabaseModel[] plyAttributes = new plyGameAttributeDatabaseModel[0];
    }
}


#endif