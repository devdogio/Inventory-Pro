﻿#if PLAYMAKER

namespace Devdog.InventoryPro.Integration.PlayMaker
{
    public class InventoryItemPlayerMakerAdapter
    {
        public InventoryItemBase item;
    }
}

#endif